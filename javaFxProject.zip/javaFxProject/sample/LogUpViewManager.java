package sample;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;


public class LogUpViewManager {
    private static final int HEIGHT=600;
    private static final int WIDTH=1024;
    private GridPane logupPane;
    private Scene logupScene;
    private Stage logupStage;


    public LogUpViewManager(){
        logupPane = new GridPane();
        logupScene = new Scene(logupPane,WIDTH,HEIGHT);
        logupStage = new Stage();
        logupStage.setTitle("Login");
        logupStage.setScene(logupScene);
        logupPane.setPadding(new Insets(10, 10, 10, 10));
        Label nameLabel = new Label("Kullanıcı adı:");
        GridPane.setConstraints(nameLabel, 0, 0);
        TextField nameInput = new TextField("");
        GridPane.setConstraints(nameInput, 1, 0);
        Label passLabel = new Label("Şifre:");
        GridPane.setConstraints(passLabel, 0, 1);
        TextField passInput = new TextField();
        GridPane.setConstraints(passInput, 1, 1);
        Label cityLbl = new Label("Yaşamak İstediği Şehir:");
        GridPane.setConstraints(cityLbl, 0, 2);
        TextField cityText = new TextField();
        GridPane.setConstraints(cityText, 1, 2);
        Button loginButton = new Button("Kayıt Ol");
        GridPane.setConstraints(loginButton, 1, 3);
        loginButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                ConnectionClass connectionClass = new ConnectionClass();
                Connection connection = connectionClass.getConnection();
                String sql="INSERT INTO `giris`(`KullaniciAdi`, `KullaniciSifre`, `yasamakisSehir`) VALUES ('"+nameInput.getText()+"','"+passInput.getText()+"','"+cityText.getText()+"')";
                 try {
                    Statement statement = connection.createStatement();
                    statement.executeUpdate(sql);
                    System.out.println("Giriş başarılı");
                } catch (SQLException e) {
                    System.out.println(e);
                }

            }
        });
        logupPane.getChildren().addAll(nameLabel, nameInput, passLabel, passInput, loginButton, cityLbl, cityText);
    }
    public Stage getMainStage(){
        return logupStage;
    }
}
