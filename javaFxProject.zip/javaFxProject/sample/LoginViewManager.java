package sample;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class LoginViewManager {
    private static final int HEIGHT=600;
    private static final int WIDTH=1024;
    private GridPane loginPane;
    private Scene loginScene;
    private Stage loginStage;


    public LoginViewManager(){
        loginPane = new GridPane();
        loginScene = new Scene(loginPane,WIDTH,HEIGHT);
        loginStage = new Stage();
        loginStage.setTitle("Login");
        loginStage.setScene(loginScene);
        loginPane.setPadding(new Insets(10, 10, 10, 10));
        Label nameLabel = new Label("Kullanıcı adı:");
        GridPane.setConstraints(nameLabel, 0, 0);
        TextField nameInput = new TextField("Emin");
        GridPane.setConstraints(nameInput, 1, 0);
        Label passLabel = new Label("Şifre:");
        GridPane.setConstraints(passLabel, 0, 1);
        TextField passInput = new TextField();
        passInput.setPromptText("12345");
        GridPane.setConstraints(passInput, 1, 1);
        Button loginButton = new Button("Giriş");
        GridPane.setConstraints(loginButton, 1, 2);
        loginButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                loginStage.hide();
                LogUpViewManager manager = new LogUpViewManager();
                manager.getMainStage().show();

                String urlStr= "http://www.tcmb.gov.tr/kurlar/today.xml";
                     //create URL object
                try {
                    URL url = new URL(urlStr);
                    Scanner scanner = new Scanner(url.openStream());
                    String line = scanner.nextLine();  //read the next line
                    System.out.println(line);
                    /*while (scanner.hasNext()){      //if the scanner has next line

                    }*/
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }


            }
        });
        loginPane.getChildren().addAll(nameLabel, nameInput, passLabel, passInput, loginButton);
    }
    public Stage getMainStage(){
        return loginStage;
    }
}
