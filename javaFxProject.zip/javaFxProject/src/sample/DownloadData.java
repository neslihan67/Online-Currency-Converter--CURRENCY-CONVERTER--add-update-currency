package sample;

public class DownloadData {
}
